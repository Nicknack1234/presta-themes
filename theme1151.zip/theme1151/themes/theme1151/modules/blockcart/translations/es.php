<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcart}prestashop>blockcart_c2e1362a9710a3dd86f937c2ea1f336d'] = 'Bloque de carrito';
$_MODULE['<{blockcart}prestashop>blockcart_e03093a5753b436ee1de63b6e3e1bd02'] = 'Añade un bloque que contiene el carrito de compra del cliente.';
$_MODULE['<{blockcart}prestashop>blockcart_a21e5718d2a196280b729438933501c7'] = 'Ajax: opción incorrecta.';
$_MODULE['<{blockcart}prestashop>blockcart_02c793e3df4632db20e4d6e146095d62'] = 'Debe rellenar el campo "productos mostrados".';
$_MODULE['<{blockcart}prestashop>blockcart_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blockcart}prestashop>blockcart_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockcart}prestashop>blockcart_614a8820aa4ac08ce2ee398a41b10778'] = 'Carrito Ajax';
$_MODULE['<{blockcart}prestashop>blockcart_eefd19ecf1f6d94a308dcfc95981bbf9'] = 'Activar el modo Ajax para la cesta (compatible con el tema por defecto).';
$_MODULE['<{blockcart}prestashop>blockcart_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockcart}prestashop>blockcart_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockcart}prestashop>blockcart_988d01745cdf3addc5fe945f362fe601'] = 'Mostrar ventas cruzadas';
$_MODULE['<{blockcart}prestashop>blockcart_8aa0413dc4bed7c55b6dfb0adc271f63'] = 'Activa la visualización de las ventas cruzadas para el carrito.';
$_MODULE['<{blockcart}prestashop>blockcart_ce8bd2479bb85218eb304a9a2903a157'] = 'Productos para mostrar en ventas cruzadas';
$_MODULE['<{blockcart}prestashop>blockcart_5f2effb52d25d197793288dfa94c27ce'] = 'Define el número de productos que se mostrarán en el bloque de ventas cruzadas.';
$_MODULE['<{blockcart}prestashop>blockcart_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcart}prestashop>blockcart_20351b3328c35ab617549920f5cb4939'] = 'Personalización n°';
$_MODULE['<{blockcart}prestashop>blockcart_ed6e9a09a111035684bb23682561e12d'] = 'eliminar este producto de mi carrito';
$_MODULE['<{blockcart}prestashop>blockcart_c6995d6cc084c192bc2e742f052a5c74'] = 'Envío gratuito!';
$_MODULE['<{blockcart}prestashop>blockcart_e7a6ca4e744870d455a57b644f696457'] = '¡Gratis!';
$_MODULE['<{blockcart}prestashop>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Eliminar';
$_MODULE['<{blockcart}prestashop>blockcart_0c3bf3014aafb90201805e45b5e62881'] = 'Ver mi carrito de compra';
$_MODULE['<{blockcart}prestashop>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Carrito:';
$_MODULE['<{blockcart}prestashop>blockcart_068f80c7519d0528fb08e82137a72131'] = 'Productos';
$_MODULE['<{blockcart}prestashop>blockcart_deb10517653c255364175796ace3553f'] = 'producto';
$_MODULE['<{blockcart}prestashop>blockcart_9e65b51e82f2a9b9f72ebe3e083582bb'] = 'vacío';
$_MODULE['<{blockcart}prestashop>blockcart_0da4d96cad73748e2f608d31cfb3247c'] = 'eliminar este producto de mi carrito';
$_MODULE['<{blockcart}prestashop>blockcart_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Detalle producto';
$_MODULE['<{blockcart}prestashop>blockcart_3d9e3bae9905a12dae384918ed117a26'] = 'Personalización n°%d:';
$_MODULE['<{blockcart}prestashop>blockcart_09dc02ecbb078868a3a86dded030076d'] = 'Ningún producto';
$_MODULE['<{blockcart}prestashop>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Transporte';
$_MODULE['<{blockcart}prestashop>blockcart_ba794350deb07c0c96fe73bd12239059'] = 'Empaque';
$_MODULE['<{blockcart}prestashop>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Impuestos';
$_MODULE['<{blockcart}prestashop>blockcart_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{blockcart}prestashop>blockcart_0d11c2b75cf03522c8d97938490466b2'] = 'Estos precios se entienden IVA incluído';
$_MODULE['<{blockcart}prestashop>blockcart_41202aa6b8cf7ae885644717dab1e8b4'] = 'Estos precios se entienden sin IVA';
$_MODULE['<{blockcart}prestashop>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'Confirmar';
$_MODULE['<{blockcart}prestashop>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'Los clientes que compraron este producto también han comprado...';
$_MODULE['<{blockcart}prestashop>crossselling_dd1f775e443ff3b9a89270713580a51b'] = 'Previo';
$_MODULE['<{blockcart}prestashop>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{blockcart}prestashop>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Siguiente';
$_MODULE['<{blockcart}prestashop>blockcart_98b3009e61879600839e1ee486bb3282'] = 'Cerrar Ventana';
$_MODULE['<{blockcart}prestashop>blockcart_544c3bd0eac526113a9c66542be1e5bc'] = 'Producto añadido correctamente a su carrito de la compra';
$_MODULE['<{blockcart}prestashop>blockcart_694e8d1f2ee056f98ee488bdc4982d73'] = 'Cantidad';
$_MODULE['<{blockcart}prestashop>blockcart_e5694b7726ceaf2f057e5f06cf86209e'] = 'Hay [1]%d[/1] artículos en su carrito.';
$_MODULE['<{blockcart}prestashop>blockcart_fc86c43dbffcadc193832a310f7a444a'] = 'Hay 1 artículo en su cesta.';
$_MODULE['<{blockcart}prestashop>blockcart_db205f01b4fd580fb5daa9072d96849d'] = 'Total productos:';
$_MODULE['<{blockcart}prestashop>blockcart_21034ae6d01a83e702839a72ba8a77b0'] = '(sin IVA)';
$_MODULE['<{blockcart}prestashop>blockcart_1f87346a16cf80c372065de3c54c86d9'] = '(impuestos inc.)';
$_MODULE['<{blockcart}prestashop>blockcart_f4e8b53a114e5a17d051ab84d326cae5'] = 'Total envío:';
$_MODULE['<{blockcart}prestashop>blockcart_300225ee958b6350abc51805dab83c24'] = 'Continuar la compra';
$_MODULE['<{blockcart}prestashop>blockcart_7e0bf6d67701868aac3116ade8fea957'] = 'Ir a la caja';


return $_MODULE;
