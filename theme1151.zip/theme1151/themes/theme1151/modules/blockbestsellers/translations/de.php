<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_9862f1949f776f69155b6e6b330c7ee1'] = 'Block Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'Block mit Verkaufshits des Shops hinzufügen.';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_b15e7271053fe9dd22d80db100179085'] = 'Das Modul kann nur an eine Spalte angedockt werden. Die gibt es aber in diesem Template nicht.';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_26986c3388870d4148b1b5375368a83d'] = 'Anzuzeigende Artikel';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'Block immer anzeigen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'Block auch anzeigen, wenn keine Verkaufshits vorhanden';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Mehr';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'Anzeigen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'Alle Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_adc570b472f54d65d3b90b8cee8368a9'] = 'Keine Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'Meistgekaufte Artikel anzeigen';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Alle Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Momentan keine Sonderangebote vorhanden';
$_MODULE['<{blockbestsellers}prestashop>tab_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Verkaufshits';
$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_09a5fe24fe0fc9ce90efc4aa507c66e7'] = 'Momentan keine Sonderangebote vorhanden.';


return $_MODULE;
