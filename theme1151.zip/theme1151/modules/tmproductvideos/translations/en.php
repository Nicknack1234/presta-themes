<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_e6880d812f1a81fba048a414fd0e84e7'] = 'TM Product Videos';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_d1eaef4cb3323090890d45422025e693'] = 'This module allow add videos to product.';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_3ee0c881516fce384747e3107dbfc538'] = 'Invalid content';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_aec6d21bda803fda4a5d419df2b9cf46'] = 'Product Videos';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_4dadf0610dad76e24e7e60d7a26a319b'] = 'You cannot manage video items from a \"All Shops\" or a \"Group Shop\" context, select directly the shop you want to edit.';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_630bbd0d82b0cff168f42e490dfd12ee'] = 'Enter link to video(Youtube, vimeo) hrere.';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_69620f6919f430e72c0f67207535605b'] = 'Video Link';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_53d56631138f8993a81069e5f6911729'] = 'Video Heading';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_a0ef73a7aaed7c4465f3eb83d269ac39'] = 'Videos description.';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_8709f470ebafd501dd8b1cb0a9c6f0a3'] = 'Videos Description';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_6dd91c1c2c3cfa2bd6c7d18c2cedd286'] = 'Video List';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_973cfc5278acccab68dcc4025776d76f'] = 'Update video';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_4aaf6f6527059065878a4e16031459a7'] = 'Remove video';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_tab_9ea67be453eaccf020697b4654fc021a'] = 'Save and stay';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_554cfab3938e21d9270bd6b75931f96f'] = 'Videos';
$_MODULE['<{tmproductvideos}prestashop>tmproductvideos_34e2d1989a1dbf75cd631596133ee5ee'] = 'Video';
