<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c393a650824fd3ac8e147306a2a1b10c'] = 'RSS SmartBlog Feed.';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_f39479e80017ac7fdf59a5d92208f88e'] = 'Genera un RSS SmartBlog Feed.';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_21ee0d457c804ed84627ec8345f3c357'] = 'La configuración ha sido actualizada con éxito.';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_70f2c15a2c9bf860a0de69d13c1f75ea'] = 'Se Requieren Todos los Campos';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c54f9f209ed8fb4683e723daa4955377'] = 'Configuración General';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_0ff5174a1c0afd0f6b8f8e9495a7262e'] = 'Actualizar Periodo';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_3d3294d044b2f8dc5fd6d34ca2dcd3ff'] = 'Actualizar Frecuencia';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c07627a5fdfbe3e2044adc04bcd675b0'] = 'Actualizar Duración';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
