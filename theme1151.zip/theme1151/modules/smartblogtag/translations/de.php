<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogtag}prestashop>smartblogtag_b84c7a512d9a3607e434c24519a97e02'] = 'Smart Blog Tafs';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_a14895030612094493056c982a7089c9'] = 'Es ist das funktionellste Modul des Blogs mit dem Block der Tags für Prestashop - von smartdatasoft';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_fa214007826415a21a8456e3e09f999d'] = 'Sind Sie sich sicher, dass Sie Ihre Details löschen möchten?';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_21ee0d457c804ed84627ec8345f3c357'] = 'Einstellungen wurden erfolgreich gespeichert.';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c54f9f209ed8fb4683e723daa4955377'] = 'Hauptparameter';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c31145c3597b3e62fe2daea13605ecac'] = 'Die Anzahl der dargestellten Tags';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_405f1bd6447ee27dff4b34065368dc4f'] = 'Die Anzahl der Tags im Post';
