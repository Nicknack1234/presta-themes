<?php
$tabvalue = array(
    array(
        'class_name' => 'AdminBlogCategory',
        'id_parent' => 15,
        'module' => 'smartblog',
        'name' => 'Blog Category',
    ),
    array(
        'class_name' => 'AdminBlogcomment',
        'id_parent' => 15,
        'module' => 'smartblog',
        'name' => 'Blog Comments',
    ),
    array(
        'class_name' => 'AdminBlogPost',
        'id_parent' => 15,
        'module' => 'smartblog',
        'name' => 'Blog Post',
    ),
    array(
        'class_name' => 'AdminImageType',
        'id_parent' => 15,
        'module' => 'smartblog',
        'name' => 'Image Type',
    )
);
?>