<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_dedc80ce5c0e352401b46ca83f4886c6'] = 'Популярные записи Smart Blog';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_ade57742867203e98e1635d4ee17299e'] = 'Наиболее функциональный модуль блога с блоком популярных записей для Prestashop - от smartdatasoft';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_fa214007826415a21a8456e3e09f999d'] = 'Вы точно хотите удалить свои детали?';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_21ee0d457c804ed84627ec8345f3c357'] = 'Настройки успешно сохранены.';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_c54f9f209ed8fb4683e723daa4955377'] = 'Основные параметры';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_3df24fbc81c688dc03a3fbc620b7915d'] = 'Количество отображаемых записей';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_3f8ab412eb8ab369ea3f5c04db23febc'] = 'Популярные статьи';
