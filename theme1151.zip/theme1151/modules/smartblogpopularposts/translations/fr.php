<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_dedc80ce5c0e352401b46ca83f4886c6'] = 'Smart Blog Aricles Populaires';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_ade57742867203e98e1635d4ee17299e'] = 'Le Plus Puissant Module d\'Articles Populaires pour Blog de shopping Presta Shop - par smartdatasoft';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_fa214007826415a21a8456e3e09f999d'] = 'Êtes-vous sûr de vouloir supprimer vos informations ?';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_21ee0d457c804ed84627ec8345f3c357'] = 'Les paramètres ont été mis à jour avec succès.';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_c54f9f209ed8fb4683e723daa4955377'] = 'Paramètres Généraux';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_3df24fbc81c688dc03a3fbc620b7915d'] = 'Nombre d\'Articles Populaires';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_3f8ab412eb8ab369ea3f5c04db23febc'] = 'Articles Populaires';
