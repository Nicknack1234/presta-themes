<?php
$tabvalue = array(
	array(
		'class_name' => 'AdminSampleDataInstallImport',
		'module' => 'sampledatainstall',
		'name' => 'Import Data',
	),
	array(
		'class_name' => 'AdminSampleDataInstallExport',
		'module' => 'sampledatainstall',
		'name' => 'Export Data',
	)
);
?>