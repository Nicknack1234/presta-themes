<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_ae7bbe3f4039ab6bac9477cff467bee9'] = 'Die neuesten Smart Blog Artikel';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_a14895030612094493056c982a7089c9'] = 'Es ist das funktionellste Modul des Blogs mit dem Block für die neuesten Artikel für Prestashop - von smartdatasoft';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_fa214007826415a21a8456e3e09f999d'] = 'Sind Sie sich sicher, dass Sie Ihre Details löschen möchten?';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_21ee0d457c804ed84627ec8345f3c357'] = 'Einstellungen wurden erfolgreich gespeichert.';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_c54f9f209ed8fb4683e723daa4955377'] = 'Hauptparameter';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_d13ccfd7bbff943d14da1ec7e75a9e73'] = 'Die Anzahl der neuesten Posts';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_58009509dfadf30a0c307129b13137d2'] = 'Die neuesten Artikel';
