<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_660a5e003bce0177d7aa7b39c1c0df5c'] = 'Новое на главной странице';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_a14895030612094493056c982a7089c9'] = 'Наиболее функциональный модуль блога с  блоком новых записей для Prestashop - от smartdatasoft';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_fa214007826415a21a8456e3e09f999d'] = 'Вы точно хотите удалить свои детали?';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_21ee0d457c804ed84627ec8345f3c357'] = 'Настройки успешно сохранены.';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_c54f9f209ed8fb4683e723daa4955377'] = 'Основные параметры';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_ea2766a70e61de99505624aa16055d4f'] = 'Количество отображаемых записей в последних новостях';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartbloghomelatestnews_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartblog_latest_news_f41378dc2401a066a07547accdc467d0'] = 'Наш';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartblog_latest_news_be8df1f28c0abc85a0ed0c6860e5d832'] = 'Блог';
$_MODULE['<{smartbloghomelatestnews}prestashop>smartblog_latest_news_decbe415d8accca7c2c16d48a79ee934'] = 'Далее';
