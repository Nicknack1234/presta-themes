<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d52ca18a939b1acb2f32144a746aa31a'] = 'Mapa de Google de TM';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_859f1a71b791416389b5fb30e3add3d6'] = 'Módulo para mostrar sus tiendas en el mapa de Google.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_0828f9482bab5f7ec09c6abe4b57b411'] = 'Configuración del Mapa de Google';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d0ca6b472cdd35ae698c37b4ce35f036'] = 'Estilo del Mapa';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_ad0758b3464113f3af88cbc4c81bd527'] = 'Tipo del Mapa';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_29afbc227d97b08a97ca3c7bc254c409'] = 'Mapa de carreteras';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c2b5e73361a4bf9d26a73413d0abee5e'] = 'Satélite';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_920fa84052b3ce64dc1f65ea3f1c5f26'] = 'Nivel de Zoom';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_55789a5bd1237991256eca0233c15476'] = 'Especificar el nivel inicial del zoom (1 - 17).';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_5e3fb3b44c0709a7435a54b1918be739'] = 'Zoom al desplazarse';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d57241971d0c3c36b89995e232af0ed0'] = 'Activar el zoom del mapa al desplazar la rueda del ratón.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_fe7d8b0235665ec6199cf29afa9c44f6'] = 'Controles de mapa';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_9cd21ce50f57ef8aefdf72b9d6d49512'] = 'Activar los elementos de control de la interfaz del mapa.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_b370d9ce079645ba296a91fdb639a529'] = 'Calles';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_46dd0ff51b2eb0b4fdd87a1b03af96e1'] = 'Activar la opción de muestra de calles.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_673ae02fffb72f0fe68a66f096a01347'] = 'Teléfono:';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_a9407a9201ef1b64f0c567ed291574ba'] = 'Obtener direcciones';
