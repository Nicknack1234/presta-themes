<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d52ca18a939b1acb2f32144a746aa31a'] = 'TM Google Map';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_859f1a71b791416389b5fb30e3add3d6'] = 'Module for displaying your stores on Google map.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_0828f9482bab5f7ec09c6abe4b57b411'] = 'Google Map Settings';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d0ca6b472cdd35ae698c37b4ce35f036'] = 'Map Style';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_ad0758b3464113f3af88cbc4c81bd527'] = 'Map Type';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_29afbc227d97b08a97ca3c7bc254c409'] = 'Roadmap';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c2b5e73361a4bf9d26a73413d0abee5e'] = 'Satellite';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_920fa84052b3ce64dc1f65ea3f1c5f26'] = 'Zoom Level';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_55789a5bd1237991256eca0233c15476'] = 'Specify initial map zoom level (1 to 17).';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_5e3fb3b44c0709a7435a54b1918be739'] = 'Zoom on scroll';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d57241971d0c3c36b89995e232af0ed0'] = 'Enable map zoom on mouse wheel scroll.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_fe7d8b0235665ec6199cf29afa9c44f6'] = 'Map controls';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_9cd21ce50f57ef8aefdf72b9d6d49512'] = 'Enable map interface control elements.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_b370d9ce079645ba296a91fdb639a529'] = 'Street view';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_46dd0ff51b2eb0b4fdd87a1b03af96e1'] = 'Enable street view option.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_630f6dc397fe74e52d5189e2c80f282b'] = 'Back to list';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_673ae02fffb72f0fe68a66f096a01347'] = 'Phone:';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_a9407a9201ef1b64f0c567ed291574ba'] = 'Get directions';
