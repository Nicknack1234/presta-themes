<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d52ca18a939b1acb2f32144a746aa31a'] = 'TM Google Karte';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_859f1a71b791416389b5fb30e3add3d6'] = 'Module für die Anzeige Ihrer Geschäfte auf der Google Karte.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_0828f9482bab5f7ec09c6abe4b57b411'] = 'Einstellungen von der Google Karte';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d0ca6b472cdd35ae698c37b4ce35f036'] = 'Kartenstile';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_ad0758b3464113f3af88cbc4c81bd527'] = 'Kartentyp';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_29afbc227d97b08a97ca3c7bc254c409'] = 'Strassenkarte';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c2b5e73361a4bf9d26a73413d0abee5e'] = 'Satellit';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_920fa84052b3ce64dc1f65ea3f1c5f26'] = 'Zoomstufe';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_55789a5bd1237991256eca0233c15476'] = 'Geben Sie ursprüngliche Zoostufe der Karte (von 1 bis 17) fest.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_5e3fb3b44c0709a7435a54b1918be739'] = 'Zoom beim Scrollen';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nein';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d57241971d0c3c36b89995e232af0ed0'] = 'Kartenzoom beim Scrollen mit dem Mausrad aktiviere.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_fe7d8b0235665ec6199cf29afa9c44f6'] = 'Steuerelemente für die Karte';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_9cd21ce50f57ef8aefdf72b9d6d49512'] = 'Steuerelemente für das Karteninterface aktivieren.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_b370d9ce079645ba296a91fdb639a529'] = 'Blick auf die Straße';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_46dd0ff51b2eb0b4fdd87a1b03af96e1'] = 'Option für den Blick auf die Straße aktivieren.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_630f6dc397fe74e52d5189e2c80f282b'] = 'Zurück zur Liste';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_673ae02fffb72f0fe68a66f096a01347'] = 'Telefonnummer';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_a9407a9201ef1b64f0c567ed291574ba'] = 'Route berechnen';
