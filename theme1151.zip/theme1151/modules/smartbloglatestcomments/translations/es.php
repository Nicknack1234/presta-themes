<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_cffd870c89d1bc2f9602491154bf2da0'] = 'Últimos Comentarios de Smart Blog';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_16aee7ae85cbeae06e31e6460184326f'] = 'Los Más Poderosos Comentarios del Módulo de Blogs de Presta shop – por smartdatasoft';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_fa214007826415a21a8456e3e09f999d'] = '¿Estás seguro de querer borrar tus datos?';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_21ee0d457c804ed84627ec8345f3c357'] = 'La configuración ha sido actualizada con éxito.';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_c54f9f209ed8fb4683e723daa4955377'] = 'Configuración General';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_3061155895da72f3fbee7c3610c3f68d'] = 'Número de Comentarios Mostrados';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_4a190b7396189db19d3156a040898e6d'] = 'Últimos Comentarios';
$_MODULE['<{smartbloglatestcomments}prestashop>smartbloglatestcomments_ed2b5c0139cec8ad2873829dc1117d50'] = 'en';
